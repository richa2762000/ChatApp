import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-share-manage-document',
  templateUrl: './share-manage-document.component.html',
  styleUrls: ['./share-manage-document.component.scss']
})
export class ShareManageDocumentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
