import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-register-successful',
  templateUrl: './register-successful.component.html',
  styleUrls: ['./register-successful.component.scss']
})
export class RegisterSuccessfulComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
